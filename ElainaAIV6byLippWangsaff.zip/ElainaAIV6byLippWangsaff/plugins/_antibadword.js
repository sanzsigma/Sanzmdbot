let badwordRegex = /uncek|unc?hek|unck|un? ck|bokep|bo?kep|0kep|okep|vcs|v?cs|suntik|sun?tik|ngewe|toket|bacol|ba?col|lonte|lon?te|coli|co?li/gacor/sosmed/UNCHEK/unhcek|vid/zonk// tambahin sendiri
export async function before(m, { isBotAdmin, isAdmin }) {
    if (m.isBaileys || m.fromMe) return 
    let chat = global.db.data.chats[m.chat]
    let user = global.db.data.users[m.sender]
    let setting = global.db.data.settings[conn.user.jid]

    let isBadword = badwordRegex.exec(m.text)
    if (chat.antiBadword && isBadword && m.isGroup) {
        if (!isAdmin) {
            user.warning += 1
            await conn.sendMessage(m.chat, { delete: m.key })
            if (setting.composing)
                await this.sendPresenceUpdate('composing', m.chat)
            if (setting.autoread)
                await this.readMessages([m.key])

            await m.reply(`${user.warning >= 5 ? '*📮 Warning Kamu Sudah Mencapai 5 Maka Kamu Akan Dikick!*' : '*📮 Kata Kata Toxic Terdeteksi*'}

あ Warning: ${user.warning} / 5

[❗] Jika warning mencapai 5 Kamu akan dikeluarkan dari group

“Barang siapa yang beriman kepada Allah dan Hari Akhir maka hendaklah dia berkata baik atau diam” (HR. al-Bukhari dan Muslim).`)
            if (user.warning >= 5) {
                user.warning = 0
            }
        }
    }
    return !0
}