import axios from 'axios';
const BASE_URL = 'https://btch.us.kg/openai?text=';
async function sendToAI(query) {
    try {
        const response = await axios.get(`${BASE_URL}${encodeURIComponent(query)}`);
        if (response.status === 200 && response.data && response.data.result) {
            return response.data.result;
        } else {
            throw new Error('Tidak ada respons atau hasil dari AI');
        }
    } catch (error) {
        console.error(error);
        throw new Error('Terjadi kesalahan saat menghubungi AI');
    }
}

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`Masukkan pertanyaan atau perintah untuk AI!\n\nContoh:\n${usedPrefix + command} Halo!`);
    }
    try {
        const aiResponse = await sendToAI(text);
        m.reply(aiResponse);
    } catch (error) {
        m.reply(`Error: ${error.message}`);
    }
};
handler.help = ['ai', 'openai'];
handler.tags = ['ai'];
handler.command = /^(ai|openai)$/i;
export default handler;