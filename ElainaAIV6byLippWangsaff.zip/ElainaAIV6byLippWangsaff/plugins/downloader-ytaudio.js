import ytdl from '@distube/ytdl-core'
import { toAudio } from '../lib/converter.js'
import fs from 'fs'
import sharp from "sharp"

let regex = /https:\/\/(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]+(\?[\w=&-]+)?|https:\/\/(?:www\.)?youtube\.com\/(?:shorts|watch)\/[a-zA-Z0-9_-]+(?:\?si=[a-zA-Z0-9_-]+)?/i

let handler = async (m, { conn, args, command, usedPrefix }) => {
    try {
        if (!conn.youtube) conn.youtube = {}
        if (!args[0]) return m.reply(`Masukan Link Youtube!\n\nContoh :\n${usedPrefix + command} https://youtu.be/Wky7Gz_5CZs`)
        let isLink = args[0].match(regex)
        if (!isLink) return m.reply("Itu bukan link youtube!")
        if (typeof conn.youtube[m.sender] !== "undefined") return m.reply("Kamu masih download!")
        await global.loading(m, conn)
        conn.youtube[m.sender] = "loading"
        let agent = ytdl.createAgent(cookies)
        let { videoDetails } = await ytdl.getInfo(args[0], { agent })
        let caption = `
*Youtube Audio Downloader*

❏ Title : ${videoDetails.title}
❏ View : ${toRupiah(videoDetails.viewCount)}
❏ Category : ${videoDetails.category}
❏ Author : ${videoDetails.ownerChannelName}
`.trim()
        let thumbnail = (await conn.getFile(videoDetails.thumbnails.reverse()[0].url)).data
        let filename = "./tmp/" + Date.now() + ".jpg"
        await sharp(thumbnail).toFormat('jpeg').toFile(filename)
        
        let chat = await conn.adReply(m.chat, caption, videoDetails.title, null, filename, args[0], m)
        let audio = await getAudio(args[0])
        let sizeMB = audio.byteLength / (1024 * 1024)
        if (sizeMB > 50000) return m.reply("Size audio terlalu besar!")
        await conn.sendFile(m.chat, audio.data, null, null, chat, false, { mimetype: "audio/mpeg" })
    } finally {
        await global.loading(m, conn, true)
        delete conn.youtube[m.sender]
    }
}
handler.help = ['ytmp3']
handler.tags = ['downloader']
handler.command = /^(yt(mp3|audio)|youtube(mp3|audio))$/i
handler.limit = true
export default handler

async function getAudio(url) {
    let randomName = new Date() * 1 + '.mp4'
    let agent = ytdl.createAgent(cookies)
    let stream = ytdl(url, {
        filter: (info) => (info.itag == 22 || info.itag == 18),
        agent
    }).pipe(fs.createWriteStream(`./tmp/${randomName}`))
    await new Promise((resolve, reject) => {
        stream.on('error', reject)
        stream.on('finish', resolve)
    })
    let audio = await toAudio(fs.readFileSync("./tmp/" + randomName), 'mp4')
    return audio
}

let getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

let toRupiah = number => parseInt(number).toLocaleString().replace(/,/g, ".")

const cookies = [
  {"name": "GPS", "value": "1"},
  {"name": "VISITOR_INFO1_LIVE", "value": "6Dc1C2Bfq4g"},
  {"name": "VISITOR_PRIVACY_METADATA", "value": "CgJJRBIEGgAgbg%3D%3D"},
  {"name": "YSC", "value": "ftsYM302vng"},
  {"name": "HSID", "value": "AO0kEVVhKrI5F7UFZ"},
  {"name": "SSID", "value": "A7KDh8dVW1jIl3soZ"},
  {"name": "APISID", "value": "jrVk_97FsCoaw-vz/AwKRFgtRvKqzf1gZd"},
  {"name": "SAPISID", "value": "6icvYlFSCdE1IfSP/Ae5rgmoX5gYe_13Tu"},
  {"name": "__Secure-1PAPISID", "value": "6icvYlFSCdE1IfSP/Ae5rgmoX5gYe_13Tu"},
  {"name": "__Secure-3PAPISID", "value": "6icvYlFSCdE1IfSP/Ae5rgmoX5gYe_13Tu"},
  {"name": "SID", "value": "g.a000rAitdixU9FhoIxkD-9BUqK2ahjAhqJL98rWEkEcUw6erOI4VG30ok1Fsmeouhwu9_bwqVAACgYKAQsSARASFQHGX2MidcU5BS42VAJ25H0AqFtEmxoVAUF8yKouWY4GTeZcOw8FB5SwpSY_0076"},
  {"name": "__Secure-1PSID", "value": "g.a000rAitdixU9FhoIxkD-9BUqK2ahjAhqJL98rWEkEcUw6erOI4Vl-XBwvk3y3hYWxbrBvn2AAACgYKATwSARASFQHGX2MiYI0zurwZt_fMjI2NvmElOhoVAUF8yKo0q3pRHnS8qHCzlrnQqFDr0076"},
  {"name": "__Secure-3PSID", "value": "g.a000rAitdixU9FhoIxkD-9BUqK2ahjAhqJL98rWEkEcUw6erOI4VgFfjxBnvjLPLDGn7tLieDAACgYKAYoSARASFQHGX2MiePiL5Q-RngJaUXW5NYpiBxoVAUF8yKron6dcc7I-SyElneCk4mB00076"},
  {"name": "PREF", "value": "f6=80&tz=Asia.Jakarta&f4=4000000"},
  {"name": "__Secure-1PSIDTS", "value": "sidts-CjIBQT4rX_1kAqJSuISDUSa7h_94mi11R_qy7mxD_NGE6YPSEuSfuQWojXPhlC_A9v_9nBAA"},
  {"name": "__Secure-3PSIDTS", "value": "sidts-CjIBQT4rX_1kAqJSuISDUSa7h_94mi11R_qy7mxD_NGE6YPSEuSfuQWojXPhlC_A9v_9nBAA"},
  {"name": "LOGIN_INFO", "value": "AFmmF2swRQIhAIZMOxl9AYJG1_d6-tCw-YqRTist4qef_fd4Soab3HEWAiBNPqehzfePSw8J1K3BILUZr2bvTmnWls5-qBmzWGdF0g:QUQ3MjNmeTdVWHBWZUZoaHNZQnQ2T3FfUFMta2JocWRQWDZsVEprNTNHdGhNeFZ0Vm1lZ1BOVzRUdTBaQm9JUGg5eUIwN2JvaG9RVHZQdk8wT25HU2taUDNKYllPNUFZQlpnNkxTSHdDYTVqQm9UT0h1Sm5tUG9vOW9UQ1Npb1lOYmMyT1poWGRBREpPaG1IYzB4QVpqT2xUak9UNnFNalBB"},
  {"name": "SIDCC", "value": "AKEyXzWjU2j0XycuAvUINknywMjopt0Yw8gLzniiuB6cqXYUBZRTK-1Ioa4YCxrIgwkD-MsE"},
  {"name": "__Secure-1PSIDCC", "value": "AKEyXzW9f0s0xz9O7FFTuIDtsHuFG7SiCDgWVf32i6LwOXaPIUyZsQOTwoRCU22D2hEMvqscjQ"},
  {"name": "__Secure-3PSIDCC", "value": "AKEyXzU94sxQ-NWFneUKKxTduDQlXqVcsYoxDPUu3WWBBhdlaClJ-cbi2cuZVdnsb4TGWoxlfA"}
]